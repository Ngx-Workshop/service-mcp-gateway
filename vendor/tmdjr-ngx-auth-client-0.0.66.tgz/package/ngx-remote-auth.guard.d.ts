import { CanActivate, ExecutionContext } from '@nestjs/common';
import { AuthClientService } from './ngx-auth-client.service';
export declare class RemoteAuthGuard implements CanActivate {
    private authClientService;
    constructor(authClientService: AuthClientService);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
