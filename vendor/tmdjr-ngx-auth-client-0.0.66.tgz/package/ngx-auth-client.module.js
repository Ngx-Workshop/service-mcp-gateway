"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NgxAuthClientModule = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const authentication_guard_1 = require("./authentication.guard");
const ngx_auth_client_service_1 = require("./ngx-auth-client.service");
const ngx_remote_auth_guard_1 = require("./ngx-remote-auth.guard");
const roles_guard_1 = require("./roles.guard");
let NgxAuthClientModule = class NgxAuthClientModule {
};
exports.NgxAuthClientModule = NgxAuthClientModule;
exports.NgxAuthClientModule = NgxAuthClientModule = __decorate([
    (0, common_1.Module)({
        imports: [axios_1.HttpModule],
        providers: [
            ngx_auth_client_service_1.AuthClientService,
            authentication_guard_1.AuthenticationGuard,
            ngx_remote_auth_guard_1.RemoteAuthGuard,
            roles_guard_1.RolesGuard,
        ],
        exports: [
            ngx_auth_client_service_1.AuthClientService,
            authentication_guard_1.AuthenticationGuard,
            ngx_remote_auth_guard_1.RemoteAuthGuard,
            roles_guard_1.RolesGuard,
        ],
    })
], NgxAuthClientModule);
//# sourceMappingURL=ngx-auth-client.module.js.map