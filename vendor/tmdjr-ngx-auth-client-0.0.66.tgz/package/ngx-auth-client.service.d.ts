import { HttpService } from '@nestjs/axios';
import { Request } from 'express';
export declare class AuthClientService {
    private httpService;
    constructor(httpService: HttpService);
    private readonly baseUrl;
    validateAccessToken(request: Request): Promise<boolean>;
}
