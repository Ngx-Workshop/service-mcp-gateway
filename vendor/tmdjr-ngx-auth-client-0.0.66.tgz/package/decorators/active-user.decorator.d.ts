import { IActiveUserData } from '../interfaces/active-user-data.interface';
export declare const ActiveUser: (...dataOrPipes: (keyof IActiveUserData | import("@nestjs/common").PipeTransform<any, any> | import("@nestjs/common").Type<import("@nestjs/common").PipeTransform<any, any>> | undefined)[]) => ParameterDecorator;
