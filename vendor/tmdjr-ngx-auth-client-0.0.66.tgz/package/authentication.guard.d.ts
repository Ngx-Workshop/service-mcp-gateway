import { CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RemoteAuthGuard } from './ngx-remote-auth.guard';
export declare class AuthenticationGuard implements CanActivate {
    private readonly reflector;
    private readonly remoteAuthGuard;
    private static readonly defaultAuthType;
    private readonly authTypeGuardMap;
    constructor(reflector: Reflector, remoteAuthGuard: RemoteAuthGuard);
    canActivate(context: ExecutionContext): Promise<boolean>;
}
