"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthClientService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const request_keys_enum_1 = require("./enums/request-keys.enum");
const role_enum_1 = require("./enums/role.enum");
function decodeJwtPayload(token) {
    try {
        const [, payloadB64] = token.split('.');
        if (!payloadB64)
            return undefined;
        const base64 = payloadB64
            .replace(/-/g, '+')
            .replace(/_/g, '/')
            .padEnd(Math.ceil(payloadB64.length / 4) * 4, '=');
        const json = Buffer.from(base64, 'base64').toString('utf8');
        const payload = JSON.parse(json);
        return {
            sub: payload.sub,
            email: payload.email ??
                payload['email_address'] ??
                payload['preferred_username'],
            role: payload.role,
        };
    }
    catch {
        return undefined;
    }
}
function getAccessTokenFromRequest(request) {
    const hdr = (Array.isArray(request.headers.authorization)
        ? request.headers.authorization[0]
        : request.headers.authorization);
    const fromHeader = hdr?.startsWith('Bearer ')
        ? hdr.slice(7).trim()
        : undefined;
    return request.cookies?.accessToken || fromHeader;
}
let AuthClientService = class AuthClientService {
    httpService;
    constructor(httpService) {
        this.httpService = httpService;
    }
    baseUrl = process.env.AUTH_BASE_URL ?? 'https://auth.ngx-workshop.io';
    async validateAccessToken(request) {
        const accessToken = getAccessTokenFromRequest(request);
        if (!accessToken)
            throw new common_1.UnauthorizedException('No access token found');
        try {
            const res = await (0, rxjs_1.firstValueFrom)(this.httpService.get(`${this.baseUrl}/validate-access-token`, {
                headers: {
                    Cookie: `accessToken=${accessToken}`,
                    Authorization: `Bearer ${accessToken}`,
                },
            }));
            if (res.data !== true)
                throw new common_1.UnauthorizedException('Invalid access token');
            const payload = decodeJwtPayload(accessToken);
            if (!payload?.sub)
                throw new common_1.UnauthorizedException('Invalid token payload');
            const existing = request[request_keys_enum_1.RequestKeys.REQUEST_USER_KEY];
            const merged = {
                sub: existing?.sub ?? payload.sub,
                email: existing?.email ?? payload.email ?? 'NOTHING_TO_SEE_HERE',
                role: existing?.role ?? payload.role ?? role_enum_1.Role.Regular,
            };
            request[request_keys_enum_1.RequestKeys.REQUEST_USER_KEY] = merged;
            if (!request.user)
                request.user = merged;
            return true;
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid access token');
        }
    }
};
exports.AuthClientService = AuthClientService;
exports.AuthClientService = AuthClientService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [axios_1.HttpService])
], AuthClientService);
//# sourceMappingURL=ngx-auth-client.service.js.map