"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthenticationGuard_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticationGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const auth_decorator_1 = require("./decorators/auth.decorator");
const auth_type_enum_1 = require("./enums/auth-type.enum");
const ngx_remote_auth_guard_1 = require("./ngx-remote-auth.guard");
let AuthenticationGuard = class AuthenticationGuard {
    static { AuthenticationGuard_1 = this; }
    reflector;
    remoteAuthGuard;
    static defaultAuthType = auth_type_enum_1.AuthType.Bearer;
    authTypeGuardMap;
    constructor(reflector, remoteAuthGuard) {
        this.reflector = reflector;
        this.remoteAuthGuard = remoteAuthGuard;
        this.authTypeGuardMap = {
            [auth_type_enum_1.AuthType.Bearer]: this.remoteAuthGuard,
            [auth_type_enum_1.AuthType.None]: { canActivate: () => true },
        };
    }
    async canActivate(context) {
        const authTypes = this.reflector.getAllAndOverride(auth_decorator_1.AUTH_TYPE_KEY, [context.getHandler(), context.getClass()]) ?? [AuthenticationGuard_1.defaultAuthType];
        const guards = authTypes
            .map((authType) => this.authTypeGuardMap[authType])
            .flat();
        let error = new common_1.UnauthorizedException('Authentication failed');
        for (const guard of guards) {
            const canActivate = await Promise.resolve(guard.canActivate(context)).catch((e) => {
                error = e;
            });
            if (canActivate)
                return true;
        }
        throw error;
    }
};
exports.AuthenticationGuard = AuthenticationGuard;
exports.AuthenticationGuard = AuthenticationGuard = AuthenticationGuard_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector,
        ngx_remote_auth_guard_1.RemoteAuthGuard])
], AuthenticationGuard);
//# sourceMappingURL=authentication.guard.js.map