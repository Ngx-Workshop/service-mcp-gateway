export interface OAuthPrincipal {
    readonly issuer: string;
    readonly subject: string;
    readonly clientId: string;
    readonly audience: string;
    readonly scopes: readonly string[];
    readonly issuedAt: number;
    readonly expiresAt: number;
}
export type OAuthVerificationFailure = 'invalid_token' | 'auth_unavailable' | 'invalid_auth_response';
export declare class OAuthVerificationError extends Error {
    readonly category: OAuthVerificationFailure;
    constructor(category: OAuthVerificationFailure);
}
export interface OAuthIntrospectionOptions {
    issuer: string;
    introspectionUrl: string;
    resource: string;
    clientId: string;
    clientSecret: string;
    allowLocalHttp?: boolean;
    timeoutMs?: number;
    maxResponseBytes?: number;
}
export declare class OAuthIntrospectionClient {
    private readonly endpoint;
    private readonly options;
    constructor(options: OAuthIntrospectionOptions);
    verifyAccessToken(token: string): Promise<OAuthPrincipal>;
}
