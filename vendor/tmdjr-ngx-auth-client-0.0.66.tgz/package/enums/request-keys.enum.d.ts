export declare enum RequestKeys {
    REQUEST_USER_KEY = "user"
}
