export declare enum Role {
    Regular = "regular",
    Publisher = "publisher",
    Admin = "admin"
}
