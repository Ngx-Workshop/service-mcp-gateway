"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestKeys = void 0;
var RequestKeys;
(function (RequestKeys) {
    RequestKeys["REQUEST_USER_KEY"] = "user";
})(RequestKeys || (exports.RequestKeys = RequestKeys = {}));
//# sourceMappingURL=request-keys.enum.js.map