"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./authentication.guard"), exports);
__exportStar(require("./decorators/active-user.decorator"), exports);
__exportStar(require("./decorators/auth.decorator"), exports);
__exportStar(require("./decorators/role.decorator"), exports);
__exportStar(require("./enums/request-keys.enum"), exports);
__exportStar(require("./enums/role.enum"), exports);
__exportStar(require("./interfaces/active-user-data.interface"), exports);
__exportStar(require("./ngx-auth-client.module"), exports);
__exportStar(require("./ngx-auth-client.service"), exports);
__exportStar(require("./ngx-remote-auth.guard"), exports);
__exportStar(require("./roles.guard"), exports);
__exportStar(require("./oauth-introspection"), exports);
//# sourceMappingURL=index.js.map