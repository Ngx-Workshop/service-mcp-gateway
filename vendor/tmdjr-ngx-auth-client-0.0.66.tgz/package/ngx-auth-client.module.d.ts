export declare class NgxAuthClientModule {
}
